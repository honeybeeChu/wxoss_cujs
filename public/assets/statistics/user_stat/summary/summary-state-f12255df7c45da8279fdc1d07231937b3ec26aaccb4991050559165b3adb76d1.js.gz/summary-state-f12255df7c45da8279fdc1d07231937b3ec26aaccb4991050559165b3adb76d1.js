define("statistics/user_stat/summary/summary-state.js", [], function () {
    "use strict";
    return {};
});
