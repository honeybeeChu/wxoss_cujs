define("statistics/interface/state.js", [], function () {
    "use strict";
    return {};
});
