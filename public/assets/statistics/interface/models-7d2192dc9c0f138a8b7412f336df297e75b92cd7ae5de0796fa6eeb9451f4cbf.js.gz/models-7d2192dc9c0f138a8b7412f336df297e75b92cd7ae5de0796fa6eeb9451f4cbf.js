define("statistics/interface/models.js", [], function () {
    "use strict";
    return {};
});
