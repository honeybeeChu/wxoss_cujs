define("tpl/searchClassifyInput.html.js", [], function () {
    return '<div id=\'js_searchDrop\'></div>\n<span class="frm_input_box">\n    <a class="del_btn jsSearchInputClose" href="javascript:" style="display:none">\n        <i class="icon_search_del"></i>&nbsp;\n    </a>\n    <input type="text" class="frm_input jsSearchInput" placeholder="文章标题">\n</span>\n<a href="javascript:;" class="btn btn_primary jsSearchInputBt">搜索</a>';
});
