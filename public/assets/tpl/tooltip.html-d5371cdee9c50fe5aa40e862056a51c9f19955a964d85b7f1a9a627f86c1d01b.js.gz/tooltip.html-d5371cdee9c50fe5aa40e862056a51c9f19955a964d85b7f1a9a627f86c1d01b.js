define("tpl/tooltip.html.js", [], function (e, t, n) {
    return '<div class="tooltip">\n    <div class="tooltip_inner">{content}</div>\n    <i class="tooltip_arrow"></i>\n</div>\n';
});
