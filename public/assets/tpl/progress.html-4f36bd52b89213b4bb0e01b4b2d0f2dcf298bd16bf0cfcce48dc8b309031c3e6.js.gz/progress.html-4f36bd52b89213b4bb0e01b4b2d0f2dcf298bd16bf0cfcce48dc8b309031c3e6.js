define("tpl/progress.html.js", [], function () {
    return '<div class="progressbar" role="progressbar" style="height:20px; position:relative; border: 1px solid #ccc;">\n    <div class="progressbar_bar" style="background:#44b549; position:absolute; height:22px; top: -1px; left: -1px; width:0%;"></div>\n    <span class="progressbar_text" style="font-size:10px; position:absolute; text-align:center; line-height:20px;"></span>\n</div>';
});
