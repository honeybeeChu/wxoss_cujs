define("tpl/searchInput.html.js", [], function () {
    return '<span class="frm_input_box search with_del append " >\n    <a class="del_btn jsSearchInputClose" href="javascript:" style="display:none">\n        <i class="icon_search_del"></i>&nbsp;\n    </a>\n    <a  href="javascript:" class="frm_input_append jsSearchInputBt">\n    	<i class="icon16_common search_gray">搜索</i>&nbsp;\n    </a>\n    <input type="text" value="" class="frm_input jsSearchInput">\n</span>';
});
