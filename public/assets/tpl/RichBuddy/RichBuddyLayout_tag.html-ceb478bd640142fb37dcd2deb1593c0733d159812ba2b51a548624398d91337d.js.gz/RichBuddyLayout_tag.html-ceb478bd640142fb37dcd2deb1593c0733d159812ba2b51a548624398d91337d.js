define("tpl/RichBuddy/RichBuddyLayout_tag.html.js", [], function () {
    return '<div class="rich_buddy popover" style="display:none;">\n    <div class="popover_inner">\n        <div class="popover_content">\n            <div class="loadingArea rich_buddy_loading"><span class="vm_box"></span><i class="icon_loading_small white"></i></div>\n            <div class="rich_buddy_bd buddyRichContent"></div>\n        </div>\n    </div>\n</div> \n';
});
