define("biz_common/jquery.validate.js", [], function () {
    !function (t) {
        t.extend(t.fn, {
            validate: function (e) {
                if (!this.length)return void(e && e.debug && window.console && console.warn("Nothing selected, can't validate, returning nothing."));
                var i = t.data(this[0], "validator");
                return i ? i : (this.attr("novalidate", "novalidate"), i = new t.validator(e, this[0]), t.data(this[0], "validator", i),
                i.settings.onsubmit && (this.validateDelegate(":submit", "click", function (e) {
                    i.settings.submitHandler && (i.submitButton = e.target), t(e.target).hasClass("cancel") && (i.cancelSubmit = !0),
                    void 0 !== t(e.target).attr("formnovalidate") && (i.cancelSubmit = !0);
                }), this.submit(function (e) {
                    function r() {
                        var r;
                        return i.settings.submitHandler ? (i.submitButton && (r = t("<input type='hidden'/>").attr("name", i.submitButton.name).val(t(i.submitButton).val()).appendTo(i.currentForm)),
                            i.settings.submitHandler.call(i, i.currentForm, e), i.submitButton && r.remove(), !1) : !0;
                    }

                    return i.settings.debug && e.preventDefault(), i.cancelSubmit ? (i.cancelSubmit = !1, r()) : i.form() ? i.pendingRequest ? (i.formSubmitted = !0,
                        !1) : r() : (i.focusInvalid(), !1);
                })), i);
            },
            valid: function () {
                if (t(this[0]).is("form"))return this.validate().form();
                var e = !0, i = t(this[0].form).validate();
                return this.each(function () {
                    e = e && i.element(this);
                }), e;
            },
            removeAttrs: function (e) {
                var i = {}, r = this;
                return t.each(e.split(/\s/), function (t, e) {
                    i[e] = r.attr(e), r.removeAttr(e);
                }), i;
            },
            rules: function (e, i) {
                var r = this[0];
                if (e) {
                    var n = t.data(r.form, "validator").settings, s = n.rules, a = t.validator.staticRules(r);
                    switch (e) {
                        case"add":
                            t.extend(a, t.validator.normalizeRule(i)), delete a.messages, s[r.name] = a, i.messages && (n.messages[r.name] = t.extend(n.messages[r.name], i.messages));
                            break;

                        case"remove":
                            if (!i)return delete s[r.name], a;
                            var o = {};
                            return t.each(i.split(/\s/), function (t, e) {
                                o[e] = a[e], delete a[e];
                            }), o;
                    }
                }
                var u = t.validator.normalizeRules(t.extend({}, t.validator.classRules(r), t.validator.attributeRules(r), t.validator.dataRules(r), t.validator.staticRules(r)), r);
                if (u.required) {
                    var l = u.required;
                    delete u.required, u = t.extend({
                        required: l
                    }, u);
                }
                return u;
            }
        }), t.extend(t.expr[":"], {
            blank: function (e) {
                return !t.trim("" + t(e).val());
            },
            filled: function (e) {
                return !!t.trim("" + t(e).val());
            },
            unchecked: function (e) {
                return !t(e).prop("checked");
            }
        }), t.validator = function (e, i) {
            this.settings = t.extend(!0, {}, t.validator.defaults, e), this.currentForm = i, this.init();
        }, t.validator.format = function (e, i) {
            return 1 === arguments.length ? function () {
                var i = t.makeArray(arguments);
                return i.unshift(e), t.validator.format.apply(this, i);
            } : (arguments.length > 2 && i.constructor !== Array && (i = t.makeArray(arguments).slice(1)),
            i.constructor !== Array && (i = [i]), t.each(i, function (t, i) {
                e = e.replace(new RegExp("\\{" + t + "\\}", "g"), function () {
                    return i;
                });
            }), e);
        }, t.extend(t.validator, {
            defaults: {
                messages: {},
                groups: {},
                rules: {},
                errorClass: "error",
                validClass: "valid",
                errorElement: "label",
                focusInvalid: !0,
                errorContainer: t([]),
                errorLabelContainer: t([]),
                onsubmit: !0,
                ignore: ":hidden",
                ignoreTitle: !1,
                onfocusin: function (t) {
                    this.lastActive = t, this.settings.focusCleanup && !this.blockFocusCleanup && (this.settings.unhighlight && this.settings.unhighlight.call(this, t, this.settings.errorClass, this.settings.validClass),
                        this.addWrapper(this.errorsFor(t)).hide());
                },
                onfocusout: function (t) {
                    this.checkable(t) || this.element(t);
                },
                onkeyup: function (t, e) {
                    (9 !== e.which || "" !== this.elementValue(t)) && (t.name in this.submitted || t === this.lastElement) && this.element(t);
                },
                onclick: function (t) {
                    t.name in this.submitted ? this.element(t) : t.parentNode.name in this.submitted && this.element(t.parentNode);
                },
                highlight: function (e, i, r) {
                    "radio" === e.type ? this.findByName(e.name).addClass(i).removeClass(r) : t(e).addClass(i).removeClass(r);
                },
                unhighlight: function (e, i, r) {
                    "radio" === e.type ? this.findByName(e.name).removeClass(i).addClass(r) : t(e).removeClass(i).addClass(r);
                }
            },
            setDefaults: function (e) {
                t.extend(t.validator.defaults, e);
            },
            messages: {
                required: "This field is required.",
                remote: "Please fix this field.",
                email: "Please enter a valid email address.",
                url: "Please enter a valid URL.",
                date: "Please enter a valid date.",
                dateISO: "Please enter a valid date (ISO).",
                number: "Please enter a valid number.",
                digits: "Please enter only digits.",
                creditcard: "Please enter a valid credit card number.",
                equalTo: "Please enter the same value again.",
                maxlength: t.validator.format("Please enter no more than {0} characters."),
                minlength: t.validator.format("Please enter at least {0} characters."),
                rangelength: t.validator.format("Please enter a value between {0} and {1} characters long."),
                range: t.validator.format("Please enter a value between {0} and {1}."),
                max: t.validator.format("Please enter a value less than or equal to {0}."),
                min: t.validator.format("Please enter a value greater than or equal to {0}.")
            },
            autoCreateRanges: !1,
            prototype: {
                init: function () {
                    function e(e) {
                        var i = t.data(this[0].form, "validator"), r = "on" + e.type.replace(/^validate/, "");
                        i.settings[r] && i.settings[r].call(i, this[0], e);
                    }

                    this.labelContainer = t(this.settings.errorLabelContainer), this.errorContext = this.labelContainer.length && this.labelContainer || t(this.currentForm),
                        this.containers = t(this.settings.errorContainer).add(this.settings.errorLabelContainer),
                        this.submitted = {}, this.valueCache = {}, this.pendingRequest = 0, this.pending = {}, this.invalid = {},
                        this.reset();
                    var i = this.groups = {};
                    t.each(this.settings.groups, function (e, r) {
                        "string" == typeof r && (r = r.split(/\s/)), t.each(r, function (t, r) {
                            i[r] = e;
                        });
                    });
                    var r = this.settings.rules;
                    t.each(r, function (e, i) {
                        r[e] = t.validator.normalizeRule(i);
                    }), t(this.currentForm).validateDelegate(":text, [type='password'], [type='file'], select, textarea, [type='number'], [type='search'] ,[type='tel'], [type='url'], [type='email'], [type='datetime'], [type='date'], [type='month'], [type='week'], [type='time'], [type='datetime-local'], [type='range'], [type='color'] ", "focusin focusout keyup", e).validateDelegate("[type='radio'], [type='checkbox'], select, option", "click", e),
                    this.settings.invalidHandler && t(this.currentForm).bind("invalid-form.validate", this.settings.invalidHandler);
                },
                form: function () {
                    return this.checkForm(), t.extend(this.submitted, this.errorMap), this.invalid = t.extend({}, this.errorMap),
                    this.valid() || t(this.currentForm).triggerHandler("invalid-form", [this]), this.showErrors(),
                        this.valid();
                },
                checkForm: function () {
                    this.prepareForm();
                    for (var t = 0, e = this.currentElements = this.elements(); e[t]; t++)this.check(e[t]);
                    return this.valid();
                },
                element: function (e) {
                    e = this.validationTargetFor(this.clean(e)), this.lastElement = e, this.prepareElement(e),
                        this.currentElements = t(e);
                    var i = this.check(e) !== !1;
                    return i ? delete this.invalid[e.name] : this.invalid[e.name] = !0, this.numberOfInvalids() || (this.toHide = this.toHide.add(this.containers)),
                        this.showErrors(), i;
                },
                showErrors: function (e) {
                    if (e) {
                        t.extend(this.errorMap, e), this.errorList = [];
                        for (var i in e)this.errorList.push({
                            message: e[i],
                            element: this.findByName(i)[0]
                        });
                        this.successList = t.grep(this.successList, function (t) {
                            return !(t.name in e);
                        });
                    }
                    this.settings.showErrors ? this.settings.showErrors.call(this, this.errorMap, this.errorList) : this.defaultShowErrors();
                },
                resetForm: function () {
                    t.fn.resetForm && t(this.currentForm).resetForm(), this.submitted = {}, this.lastElement = null,
                        this.prepareForm(), this.hideErrors(), this.elements().removeClass(this.settings.errorClass).removeData("previousValue");
                },
                numberOfInvalids: function () {
                    return this.objectLength(this.invalid);
                },
                objectLength: function (t) {
                    var e = 0;
                    for (var i in t)e++;
                    return e;
                },
                hideErrors: function () {
                    this.addWrapper(this.toHide).hide();
                },
                valid: function () {
                    return 0 === this.size();
                },
                size: function () {
                    return this.errorList.length;
                },
                focusInvalid: function () {
                    if (this.settings.focusInvalid)try {
                        t(this.findLastActive() || this.errorList.length && this.errorList[0].element || []).filter(":visible").focus().trigger("focusin");
                    } catch (e) {
                    }
                },
                findLastActive: function () {
                    var e = this.lastActive;
                    return e && 1 === t.grep(this.errorList, function (t) {
                            return t.element.name === e.name;
                        }).length && e;
                },
                elements: function () {
                    var e = this, i = {};
                    return t(this.currentForm).find("input, select, textarea").not(":submit, :reset, :image, [disabled]").not(this.settings.ignore).filter(function () {
                        return !this.name && e.settings.debug && window.console && console.error("%o has no name assigned", this),
                            this.name in i || !e.objectLength(t(this).rules()) ? !1 : (i[this.name] = !0, !0);
                    });
                },
                clean: function (e) {
                    return t(e)[0];
                },
                errors: function () {
                    var e = this.settings.errorClass.replace(" ", ".");
                    return t(this.settings.errorElement + "." + e, this.errorContext);
                },
                reset: function () {
                    this.successList = [], this.errorList = [], this.errorMap = {}, this.toShow = t([]), this.toHide = t([]),
                        this.currentElements = t([]);
                },
                prepareForm: function () {
                    this.reset(), this.toHide = this.errors().add(this.containers);
                },
                prepareElement: function (t) {
                    this.reset(), this.toHide = this.errorsFor(t);
                },
                elementValue: function (e) {
                    var i = t(e).attr("type"), r = t(e).val();
                    return "radio" === i || "checkbox" === i ? t("input[name='" + t(e).attr("name") + "']:checked").val() : "string" == typeof r ? r.replace(/\r/g, "") : r;
                },
                check: function (e) {
                    e = this.validationTargetFor(this.clean(e));
                    var i, r = t(e).rules(), n = !1, s = this.elementValue(e);
                    for (var a in r) {
                        var o = {
                            method: a,
                            parameters: r[a]
                        };
                        try {
                            if (i = t.validator.methods[a].call(this, s, e, o.parameters), "dependency-mismatch" === i) {
                                n = !0;
                                continue;
                            }
                            if (n = !1, "pending" === i)return void(this.toHide = this.toHide.not(this.errorsFor(e)));
                            if (!i)return this.formatAndAdd(e, o), !1;
                        } catch (u) {
                            throw this.settings.debug && window.console && console.log("Exception occurred when checking element " + e.id + ", check the '" + o.method + "' method.", u),
                                u;
                        }
                    }
                    return n ? void 0 : (this.objectLength(r) && this.successList.push(e), !0);
                },
                customDataMessage: function (e, i) {
                    return t(e).data("msg-" + i.toLowerCase()) || e.attributes && t(e).attr("data-msg-" + i.toLowerCase());
                },
                customMessage: function (t, e) {
                    var i = this.settings.messages[t];
                    return i && (i.constructor === String ? i : i[e]);
                },
                findDefined: function () {
                    for (var t = 0; t < arguments.length; t++)if (void 0 !== arguments[t])return arguments[t];
                    return void 0;
                },
                defaultMessage: function (e, i) {
                    return this.findDefined(this.customMessage(e.name, i), this.customDataMessage(e, i), !this.settings.ignoreTitle && e.title || void 0, t.validator.messages[i], "<strong>Warning: No message defined for " + e.name + "</strong>");
                },
                formatAndAdd: function (e, i) {
                    var r = this.defaultMessage(e, i.method), n = /\$?\{(\d+)\}/g;
                    "function" == typeof r ? r = r.call(this, i.parameters, e) : n.test(r) && (r = t.validator.format(r.replace(n, "{$1}"), i.parameters)),
                        this.errorList.push({
                            message: r,
                            element: e
                        }), this.errorMap[e.name] = r, this.submitted[e.name] = r;
                },
                addWrapper: function (t) {
                    return this.settings.wrapper && (t = t.add(t.parent(this.settings.wrapper))), t;
                },
                defaultShowErrors: function () {
                    var t, e;
                    for (t = 0; this.errorList[t]; t++) {
                        var i = this.errorList[t];
                        this.settings.highlight && this.settings.highlight.call(this, i.element, this.settings.errorClass, this.settings.validClass),
                            this.showLabel(i.element, i.message);
                    }
                    if (this.errorList.length && (this.toShow = this.toShow.add(this.containers)), this.settings.success)for (t = 0; this.successList[t]; t++)this.showLabel(this.successList[t]);
                    if (this.settings.unhighlight)for (t = 0, e = this.validElements(); e[t]; t++)this.settings.unhighlight.call(this, e[t], this.settings.errorClass, this.settings.validClass);
                    this.toHide = this.toHide.not(this.toShow), this.hideErrors(), this.addWrapper(this.toShow).show();
                },
                validElements: function () {
                    return this.currentElements.not(this.invalidElements());
                },
                invalidElements: function () {
                    return t(this.errorList).map(function () {
                        return this.element;
                    });
                },
                showLabel: function (e, i) {
                    var r = this.errorsFor(e);
                    r.length ? (r.removeClass(this.settings.validClass).addClass(this.settings.errorClass),
                        r.html(i)) : (r = t("<" + this.settings.errorElement + ">").attr("for", this.idOrName(e)).addClass(this.settings.errorClass).html(i || ""),
                    this.settings.wrapper && (r = r.hide().show().wrap("<" + this.settings.wrapper + " class='frm_msg fail'/>").parent()),
                    this.labelContainer.append(r).length || (this.settings.errorPlacement ? this.settings.errorPlacement(r, t(e)) : r.insertAfter(e))),
                    !i && this.settings.success && (r.text(""), "string" == typeof this.settings.success ? r.addClass(this.settings.success) : this.settings.success(r, e)),
                        this.toShow = this.toShow.add(r);
                },
                errorsFor: function (e) {
                    var i = this.idOrName(e);
                    return this.errors().filter(function () {
                        return t(this).attr("for") === i;
                    });
                },
                idOrName: function (t) {
                    return this.groups[t.name] || (this.checkable(t) ? t.name : t.id || t.name);
                },
                validationTargetFor: function (t) {
                    return this.checkable(t) && (t = this.findByName(t.name).not(this.settings.ignore)[0]),
                        t;
                },
                checkable: function (t) {
                    return /radio|checkbox/i.test(t.type);
                },
                findByName: function (e) {
                    return t(this.currentForm).find("[name='" + e + "']");
                },
                getLength: function (e, i) {
                    switch (i.nodeName.toLowerCase()) {
                        case"select":
                            return t("option:selected", i).length;

                        case"input":
                            if (this.checkable(i))return this.findByName(i.name).filter(":checked").length;
                    }
                    return e.length;
                },
                depend: function (t, e) {
                    return this.dependTypes[typeof t] ? this.dependTypes[typeof t](t, e) : !0;
                },
                dependTypes: {
                    "boolean": function (t) {
                        return t;
                    },
                    string: function (e, i) {
                        return !!t(e, i.form).length;
                    },
                    "function": function (t, e) {
                        return t(e);
                    }
                },
                optional: function (e) {
                    var i = this.elementValue(e);
                    return !t.validator.methods.required.call(this, i, e) && "dependency-mismatch";
                },
                startRequest: function (t) {
                    this.pending[t.name] || (this.pendingRequest++, this.pending[t.name] = !0);
                },
                stopRequest: function (e, i) {
                    this.pendingRequest--, this.pendingRequest < 0 && (this.pendingRequest = 0), delete this.pending[e.name],
                        i && 0 === this.pendingRequest && this.formSubmitted && this.form() ? (t(this.currentForm).submit(),
                            this.formSubmitted = !1) : !i && 0 === this.pendingRequest && this.formSubmitted && (t(this.currentForm).triggerHandler("invalid-form", [this]),
                            this.formSubmitted = !1);
                },
                previousValue: function (e) {
                    return t.data(e, "previousValue") || t.data(e, "previousValue", {
                            old: null,
                            valid: !0,
                            message: this.defaultMessage(e, "remote")
                        });
                }
            },
            classRuleSettings: {
                required: {
                    required: !0
                },
                email: {
                    email: !0
                },
                url: {
                    url: !0
                },
                date: {
                    date: !0
                },
                dateISO: {
                    dateISO: !0
                },
                number: {
                    number: !0
                },
                digits: {
                    digits: !0
                },
                creditcard: {
                    creditcard: !0
                }
            },
            addClassRules: function (e, i) {
                e.constructor === String ? this.classRuleSettings[e] = i : t.extend(this.classRuleSettings, e);
            },
            classRules: function (e) {
                var i = {}, r = t(e).attr("class");
                return r && t.each(r.split(" "), function () {
                    this in t.validator.classRuleSettings && t.extend(i, t.validator.classRuleSettings[this]);
                }), i;
            },
            attributeRules: function (e) {
                var i = {}, r = t(e), n = r[0].getAttribute("type");
                for (var s in t.validator.methods) {
                    var a;
                    "required" === s ? (a = r.get(0).getAttribute(s), "" === a && (a = !0), a = !!a) : a = r.attr(s), /min|max/.test(s) && (null === n || /number|range|text/.test(n)) && (a = Number(a)),
                        a ? i[s] = a : n === s && "range" !== n && (i[s] = !0);
                }
                return i.maxlength && /-1|2147483647|524288/.test(i.maxlength) && delete i.maxlength,
                    i;
            },
            dataRules: function (e) {
                var i, r, n = {}, s = t(e);
                for (i in t.validator.methods)r = s.data("rule-" + i.toLowerCase()), void 0 !== r && (n[i] = r);
                return n;
            },
            staticRules: function (e) {
                var i = {}, r = t.data(e.form, "validator");
                return r.settings.rules && (i = t.validator.normalizeRule(r.settings.rules[e.name]) || {}),
                    i;
            },
            normalizeRules: function (e, i) {
                return t.each(e, function (r, n) {
                    if (n === !1)return void delete e[r];
                    if (n.param || n.depends) {
                        var s = !0;
                        switch (typeof n.depends) {
                            case"string":
                                s = !!t(n.depends, i.form).length;
                                break;

                            case"function":
                                s = n.depends.call(i, i);
                        }
                        s ? "string" != typeof n && (e[r] = void 0 !== n.param ? n.param : !0) : delete e[r];
                    }
                }), t.each(e, function (r, n) {
                    e[r] = t.isFunction(n) ? n(i) : n;
                }), t.each(["minlength", "maxlength"], function () {
                    e[this] && (e[this] = Number(e[this]));
                }), t.each(["rangelength", "range"], function () {
                    var i;
                    e[this] && (t.isArray(e[this]) ? e[this] = [Number(e[this][0]), Number(e[this][1])] : "string" == typeof e[this] && (i = e[this].split(/[\s,]+/),
                        e[this] = [Number(i[0]), Number(i[1])]));
                }), t.validator.autoCreateRanges && (e.min && e.max && (e.range = [e.min, e.max], delete e.min,
                    delete e.max), e.minlength && e.maxlength && (e.rangelength = [e.minlength, e.maxlength],
                    delete e.minlength, delete e.maxlength)), e;
            },
            normalizeRule: function (e) {
                if ("string" == typeof e) {
                    var i = {};
                    t.each(e.split(/\s/), function () {
                        i[this] = !0;
                    }), e = i;
                }
                return e;
            },
            addMethod: function (e, i, r) {
                t.validator.methods[e] = i, t.validator.messages[e] = void 0 !== r ? r : t.validator.messages[e],
                i.length < 3 && t.validator.addClassRules(e, t.validator.normalizeRule(e));
            },
            methods: {
                required: function (e, i, r) {
                    if (!this.depend(r, i))return "dependency-mismatch";
                    if ("select" === i.nodeName.toLowerCase()) {
                        var n = t(i).val();
                        return n && n.length > 0;
                    }
                    return this.checkable(i) ? this.getLength(e, i) > 0 : t.trim(e).length > 0;
                },
                email: function (t, e) {
                    return this.optional(e) || /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))$/i.test(t);
                },
                url: function (t, e) {
                    return this.optional(e) || /^(https?|s?ftp|weixin):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i.test(t);
                },
                date: function (t, e) {
                    return this.optional(e) || !/Invalid|NaN/.test(new Date(t).toString());
                },
                dateISO: function (t, e) {
                    return this.optional(e) || /^\d{4}[\/\-]\d{1,2}[\/\-]\d{1,2}$/.test(t);
                },
                number: function (t, e) {
                    return this.optional(e) || /^-?(?:\d+|\d{1,3}(?:,\d{3})+)?(?:\.\d+)?$/.test(t);
                },
                digits: function (t, e) {
                    return this.optional(e) || /^\d+$/.test(t);
                },
                creditcard: function (t, e) {
                    if (this.optional(e))return "dependency-mismatch";
                    if (/[^0-9 \-]+/.test(t))return !1;
                    var i = 0, r = 0, n = !1;
                    t = t.replace(/\D/g, "");
                    for (var s = t.length - 1; s >= 0; s--) {
                        var a = t.charAt(s);
                        r = parseInt(a, 10), n && (r *= 2) > 9 && (r -= 9), i += r, n = !n;
                    }
                    return i % 10 === 0;
                },
                minlength: function (e, i, r) {
                    var n = t.isArray(e) ? e.length : this.getLength(t.trim(e), i);
                    return this.optional(i) || n >= r;
                },
                maxlength: function (e, i, r) {
                    var n = t.isArray(e) ? e.length : this.getLength(t.trim(e), i);
                    return this.optional(i) || r >= n;
                },
                rangelength: function (e, i, r) {
                    var n = t.isArray(e) ? e.length : this.getLength(t.trim(e), i);
                    return this.optional(i) || n >= r[0] && n <= r[1];
                },
                min: function (t, e, i) {
                    return this.optional(e) || t >= i;
                },
                max: function (t, e, i) {
                    return this.optional(e) || i >= t;
                },
                range: function (t, e, i) {
                    return this.optional(e) || t >= i[0] && t <= i[1];
                },
                equalTo: function (e, i, r) {
                    var n = t(r);
                    return this.settings.onfocusout && n.unbind(".validate-equalTo").bind("blur.validate-equalTo", function () {
                        t(i).valid();
                    }), e === n.val();
                },
                remote: function (e, i, r) {
                    if (this.optional(i))return "dependency-mismatch";
                    var n = this.previousValue(i);
                    if (this.settings.messages[i.name] || (this.settings.messages[i.name] = {}), n.originalMessage = this.settings.messages[i.name].remote,
                            this.settings.messages[i.name].remote = n.message, r = "string" == typeof r && {
                                url: r
                            } || r, n.old === e)return n.valid;
                    n.old = e;
                    var s = this;
                    this.startRequest(i);
                    var a = {};
                    return a[i.name] = e, t.ajax(t.extend(!0, {
                        url: r,
                        mode: "abort",
                        port: "validate" + i.name,
                        dataType: "json",
                        data: a,
                        success: function (r) {
                            s.settings.messages[i.name].remote = n.originalMessage;
                            var a = r === !0 || "true" === r;
                            if (a) {
                                var o = s.formSubmitted;
                                s.prepareElement(i), s.formSubmitted = o, s.successList.push(i), delete s.invalid[i.name],
                                    s.showErrors();
                            } else {
                                var u = {}, l = r || s.defaultMessage(i, "remote");
                                u[i.name] = n.message = t.isFunction(l) ? l(e) : l, s.invalid[i.name] = !0, s.showErrors(u);
                            }
                            n.valid = a, s.stopRequest(i, a);
                        }
                    }, r)), "pending";
                }
            }
        }), t.format = t.validator.format;
    }(jQuery), function (t) {
        var e = {};
        if (t.ajaxPrefilter)t.ajaxPrefilter(function (t, i, r) {
            var n = t.port;
            "abort" === t.mode && (e[n] && e[n].abort(), e[n] = r);
        }); else {
            var i = t.ajax;
            t.ajax = function (r) {
                var n = ("mode" in r ? r : t.ajaxSettings).mode, s = ("port" in r ? r : t.ajaxSettings).port;
                return "abort" === n ? (e[s] && e[s].abort(), e[s] = i.apply(this, arguments), e[s]) : i.apply(this, arguments);
            };
        }
    }(jQuery), function (t) {
        t.extend(t.fn, {
            validateDelegate: function (e, i, r) {
                return this.bind(i, function (i) {
                    var n = t(i.target);
                    return n.is(e) ? r.apply(n, arguments) : void 0;
                });
            }
        });
    }(jQuery), function (t) {
        t.validator.defaults.errorClass = "frm_msg_content", t.validator.defaults.errorElement = "span",
            t.validator.defaults.errorPlacement = function (t, e) {
                e.parent().after(t);
            }, t.validator.defaults.wrapper = "p", t.validator.messages = {
            required: "必选字段",
            remote: "请修正该字段",
            email: "请输入正确格式的电子邮件",
            url: "请输入合法的网址",
            date: "请输入合法的日期",
            dateISO: "请输入合法的日期 (ISO).",
            number: "请输入合法的数字",
            digits: "只能输入整数",
            creditcard: "请输入合法的信用卡号",
            equalTo: "请再次输入相同的值",
            accept: "请输入拥有合法后缀名的字符串",
            maxlength: t.validator.format("请输入一个长度最多是 {0} 的字符串"),
            minlength: t.validator.format("请输入一个长度最少是 {0} 的字符串"),
            rangelength: t.validator.format("请输入一个长度介于 {0} 和 {1} 之间的字符串"),
            range: t.validator.format("请输入一个介于 {0} 和 {1} 之间的值"),
            max: t.validator.format("请输入一个最大为 {0} 的值"),
            min: t.validator.format("请输入一个最小为 {0} 的值")
        }, function () {
            function e(t) {
                var e, i = 0;
                "x" == t[17].toLowerCase() && (t[17] = 10);
                for (var r = 0; 17 > r; r++)i += n[r] * t[r];
                return e = i % 11, t[17] == s[e] ? !0 : !1;
            }

            function i(t) {
                var e = t.substring(6, 10), i = t.substring(10, 12), r = t.substring(12, 14), n = new Date(e, parseFloat(i) - 1, parseFloat(r));
                return (new Date).getFullYear() - parseInt(e) < 18 ? !1 : n.getFullYear() != parseFloat(e) || n.getMonth() != parseFloat(i) - 1 || n.getDate() != parseFloat(r) ? !1 : !0;
            }

            function r(r) {
                if (r = t.trim(r.replace(/ /g, "")), 15 == r.length)return !1;
                if (18 == r.length) {
                    var n = r.split("");
                    return i(r) && e(n) ? !0 : !1;
                }
                return !1;
            }

            var n = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2, 1], s = [1, 0, 10, 9, 8, 7, 6, 5, 4, 3, 2];
            t.validator.addMethod("idcard", function (t) {
                return r(t);
            }, "身份证格式不正确，或者年龄未满18周岁，请重新填写"), t.validator.addMethod("mobile", function (e) {
                return e = t.trim(e), /^1\d{10}$/.test(e);
            }, "请输入正确的手机号码"), t.validator.addMethod("telephone", function (e) {
                return e = t.trim(e), /^\d{1,4}(-\d{1,12})+$/.test(e);
            }, "请输入正确的座机号码，如020-12345678"), t.validator.addMethod("verifycode", function (e) {
                return e = t.trim(e), /^\d{6}$/.test(e);
            }, "验证码应为6位数字"), t.validator.addMethod("byteRangeLength", function (t, e, i) {
                return this.optional(e) || t.len() <= i[1] && t.len() >= i[0];
            }, "_(必须为{0}到{1}个字节之间)");
        }();
    }(jQuery);
    var t = {
        optional: function () {
            return !1;
        },
        getLength: function (t) {
            return t ? t.length : 0;
        }
    }, e = $.validator;
    return e.rules = {}, $.each(e.methods, function (i, r) {
        e.rules[i] = function (e, i) {
            return r.call(t, e, null, i);
        };
    }), e;
});
