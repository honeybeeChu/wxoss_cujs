define("biz_common/utils/huatuo.js", [], function () {
    var t = window.performance && window.performance.timing,
        n = "http://report.huatuo.qq.com/report.cgi?appid=10065&speedparams=",
        o = t ? ["unloadEventStart", "unloadEventEnd", "redirectStart", "redirectEnd", "fetchStart", "domainLookupStart",
            "domainLookupEnd", "connectStart", "connectEnd", "requestStart", "responseStart", "responseEnd", "domLoading",
            "domInteractive", "domContentLoadedEventStart", "domContentLoadedEventEnd", "domComplete", "loadEventStart",
            "loadEventEnd"] : [],
        e = {
            points: [],
            setFlags: function (n, r, a) {
                e.points = ["flag1=" + n, "flag2=" + r, "flag3=" + a];
                for (var d = 0; d < o.length; ++d)e.points.push(d + 1 + "=" + t[o[d]]);
            },
            setPoint: function (t, n) {
                return this.points.push(t + "=" + n), this;
            },
            report: function () {
                var t = this.points.join("&");
                t = encodeURIComponent(t), (new Image).src = n + t, e.points = [];
            }
        };
    return e;
});
