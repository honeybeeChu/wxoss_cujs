define("common/wx/time.js", [], function () {
    "use strict";
    function e(e) {
        var t = new Date(1e3 * e), r = new Date, g = t.getTime(), a = r.getTime(), u = 864e5;
        return u > a - g && r.getDate() == t.getDate() ? "%s:%s".sprintf(n(t.getHours()), n(t.getMinutes())) : 2 * u > a - g && new Date(1 * t + u).getDate() == r.getDate() ? "昨天 %s:%s".sprintf(n(t.getHours()), n(t.getMinutes())) : 6 * u >= a - g ? "%s %s:%s".sprintf(s[t.getDay()], n(t.getHours()), n(t.getMinutes())) : t.getFullYear() == r.getFullYear() ? "%s月%s日".sprintf(n(t.getMonth() + 1), n(t.getDate())) : "%s年%s月%s日".sprintf(t.getFullYear(), n(t.getMonth() + 1), n(t.getDate()));
    }

    function t(e) {
        var t = new Date(1e3 * e);
        return "%s-%s-%s %s:%s:%s".sprintf(t.getFullYear(), n(t.getMonth() + 1), n(t.getDate()), n(t.getHours()), n(t.getMinutes()), n(t.getSeconds()));
    }

    function r(e, t) {
        var r = ["日", "一", "二", "三", "四", "五", "六"], n = t.replace(/yyyy|YYYY/, e.getFullYear()).replace(/yy|YY/, g(e.getFullYear() % 100, 2)).replace(/mm|MM/, g(e.getMonth() + 1, 2)).replace(/m|M/g, e.getMonth() + 1).replace(/dd|DD/, g(e.getDate(), 2)).replace(/d|D/g, e.getDate()).replace(/hh|HH/, g(e.getHours(), 2)).replace(/h|H/g, e.getHours()).replace(/ii|II/, g(e.getMinutes(), 2)).replace(/i|I/g, e.getMinutes()).replace(/ss|SS/, g(e.getSeconds(), 2)).replace(/s|S/g, e.getSeconds()).replace(/w/g, e.getDay()).replace(/W/g, r[e.getDay()]);
        return n;
    }

    function g(e, t) {
        for (var r = 0, g = t - (e + "").length; g > r; r++)e = "0" + e;
        return e + "";
    }

    var n = function (e) {
        return e += "", e.length >= 2 ? e : "0" + e;
    }, s = ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"];
    return {
        timeFormat: e,
        getFullTime: t,
        formatDate: r
    };
});
